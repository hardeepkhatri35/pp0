
import AdminPanel from "@/components/AdminPanel";

const Admin = () => {
  return <AdminPanel />;
};

export default Admin;
